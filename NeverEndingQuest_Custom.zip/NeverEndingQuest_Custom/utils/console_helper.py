"""
Console Helper - Utilities for formatted console output
"""

import os
import sys


class ConsoleHelper:
    """Helper class for console formatting and output"""
    
    def __init__(self):
        self.colors_enabled = self._check_color_support()
        
    def _check_color_support(self):
        """Check if terminal supports colors"""
        # Simple check - assume colors work on most systems
        return sys.stdout.isatty()
        
    def clear(self):
        """Clear the console"""
        os.system('cls' if os.name == 'nt' else 'clear')
        
    def print_header(self, text):
        """Print a header"""
        width = 80
        print("\n" + "=" * width)
        print(text.center(width))
        print("=" * width + "\n")
        
    def print_separator(self):
        """Print a separator line"""
        print("-" * 80)
        
    def print_dm(self, text):
        """Print DM narration"""
        if self.colors_enabled:
            print(f"\n\033[94m{text}\033[0m")  # Blue text
        else:
            print(f"\n[DM] {text}")
            
    def print_success(self, text):
        """Print success message"""
        if self.colors_enabled:
            print(f"\033[92m{text}\033[0m")  # Green text
        else:
            print(f"[SUCCESS] {text}")
            
    def print_error(self, text):
        """Print error message"""
        if self.colors_enabled:
            print(f"\033[91m{text}\033[0m")  # Red text
        else:
            print(f"[ERROR] {text}")
            
    def print_info(self, text):
        """Print info message"""
        if self.colors_enabled:
            print(f"\033[93m{text}\033[0m")  # Yellow text
        else:
            print(f"[INFO] {text}")
            
    def print_combat(self, text):
        """Print combat text"""
        if self.colors_enabled:
            print(f"\033[91m⚔️  {text}\033[0m")  # Red text with sword
        else:
            print(f"[COMBAT] {text}")
            
    def print_character_info(self, character):
        """Print character information"""
        self.print_separator()
        print(f"Name: {character.get('name', 'Unknown')}")
        print(f"Level {character.get('level', 1)} {character.get('class', 'Adventurer')}")
        print(f"HP: {character.get('current_hp', 0)}/{character.get('max_hp', 0)}")
        print(f"XP: {character.get('xp', 0)}")
        self.print_separator()
        
    def print_box(self, text, width=80):
        """Print text in a box"""
        lines = text.split('\n')
        print("┌" + "─" * (width - 2) + "┐")
        for line in lines:
            padding = width - len(line) - 4
            print(f"│ {line}{' ' * padding} │")
        print("└" + "─" * (width - 2) + "┘")
        
    def get_choice(self, prompt, options):
        """Get a choice from the user"""
        print(f"\n{prompt}")
        for i, option in enumerate(options, 1):
            print(f"{i}. {option}")
            
        while True:
            try:
                choice = int(input("\nYour choice: ").strip())
                if 1 <= choice <= len(options):
                    return choice - 1
                else:
                    self.print_error("Invalid choice. Try again.")
            except ValueError:
                self.print_error("Please enter a number.")
                
    def confirm(self, prompt):
        """Get yes/no confirmation"""
        response = input(f"{prompt} (y/n): ").strip().lower()
        return response in ['y', 'yes']
        
    def print_loading(self, text="Loading"):
        """Print loading message"""
        print(f"\n{text}...", end="", flush=True)
        
    def print_done(self):
        """Print done message"""
        print(" Done!")
