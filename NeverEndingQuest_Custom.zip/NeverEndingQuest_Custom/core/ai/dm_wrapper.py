"""
DM Wrapper - Handles communication with AI models for game mastering
"""

import os
import sys
from pathlib import Path

try:
    import config
except ImportError:
    print("ERROR: config.py not found!")
    sys.exit(1)

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: OpenAI package not installed. Run: pip install openai")
    sys.exit(1)


class DMWrapper:
    """Wrapper for AI Dungeon Master"""
    
    def __init__(self):
        self.client = None
        self.conversation_history = []
        self.system_prompt = self.load_system_prompt()
        
        # Initialize OpenAI client
        if hasattr(config, 'OPENAI_API_KEY'):
            self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        else:
            raise ValueError("OPENAI_API_KEY not found in config.py")
            
    def load_system_prompt(self):
        """Load the system prompt for the DM"""
        prompt_path = Path("prompts/system_prompt.txt")
        
        if prompt_path.exists():
            with open(prompt_path, 'r', encoding='utf-8') as f:
                return f.read()
        else:
            # Default prompt
            return """You are an expert Dungeon Master for a D&D 5th Edition game.

Your role:
- Narrate the adventure with vivid, engaging descriptions
- Respond to player actions with appropriate outcomes
- Manage combat, skill checks, and game mechanics
- Create interesting NPCs and dialogue
- Maintain game balance and fun

Rules:
- Follow D&D 5e rules accurately
- Be fair but challenging
- Encourage creative problem-solving
- Keep the story moving forward
- Ask for dice rolls when appropriate

Format your responses naturally as a DM would speak to players.
"""
    
    def start_adventure(self, character):
        """Start a new adventure"""
        character_info = self._format_character_info(character)
        
        prompt = f"""A new adventure begins!

{character_info}

As the Dungeon Master, set the scene and begin the adventure. Where does the character start their journey?"""

        return self._send_to_ai(prompt, include_system=True)
        
    def process_action(self, user_input, character):
        """Process a player action"""
        character_info = self._format_character_info(character)
        
        prompt = f"""Character: {character['name']}
Current HP: {character.get('current_hp', character.get('max_hp', 10))}/{character.get('max_hp', 10)}

Player action: {user_input}

As the DM, describe what happens next."""

        return self._send_to_ai(prompt)
        
    def _format_character_info(self, character):
        """Format character information for the AI"""
        info = []
        info.append(f"Name: {character.get('name', 'Unknown')}")
        info.append(f"Race: {character.get('race', 'Human')}")
        info.append(f"Class: {character.get('class', 'Fighter')}")
        info.append(f"Level: {character.get('level', 1)}")
        info.append(f"HP: {character.get('current_hp', 10)}/{character.get('max_hp', 10)}")
        
        if 'equipment' in character:
            equipment = character['equipment']
            info.append(f"\nEquipment:")
            for item in equipment[:5]:  # Show first 5 items
                info.append(f"  - {item}")
                
        return "\n".join(info)
        
    def _send_to_ai(self, prompt, include_system=False):
        """Send a prompt to the AI and get response"""
        messages = []
        
        # Add system prompt if needed
        if include_system:
            messages.append({
                "role": "system",
                "content": self.system_prompt
            })
            
        # Add conversation history
        messages.extend(self.conversation_history[-10:])  # Keep last 10 messages
        
        # Add current prompt
        messages.append({
            "role": "user",
            "content": prompt
        })
        
        try:
            # Call OpenAI API
            response = self.client.chat.completions.create(
                model=config.DM_MAIN_MODEL,
                messages=messages,
                temperature=getattr(config, 'STORYTELLING_TEMPERATURE', 0.8),
                max_tokens=getattr(config, 'MAX_RESPONSE_TOKENS', 4000)
            )
            
            ai_response = response.choices[0].message.content
            
            # Update conversation history
            self.conversation_history.append({
                "role": "user",
                "content": prompt
            })
            self.conversation_history.append({
                "role": "assistant",
                "content": ai_response
            })
            
            return ai_response
            
        except Exception as e:
            return f"Error communicating with AI: {e}"
            
    def clear_history(self):
        """Clear conversation history"""
        self.conversation_history = []
        
    def compress_history(self):
        """Compress conversation history to save tokens"""
        if len(self.conversation_history) > 20:
            # Keep first 2 and last 10 messages, summarize the middle
            start = self.conversation_history[:2]
            end = self.conversation_history[-10:]
            middle = self.conversation_history[2:-10]
            
            # Create summary of middle section
            summary_prompt = "Summarize these game events in 2-3 sentences:\n\n"
            for msg in middle:
                if msg['role'] == 'user':
                    summary_prompt += f"Player: {msg['content'][:100]}...\n"
                    
            try:
                response = self.client.chat.completions.create(
                    model=config.DM_SUMMARIZATION_MODEL,
                    messages=[{"role": "user", "content": summary_prompt}],
                    temperature=0.3,
                    max_tokens=200
                )
                
                summary = response.choices[0].message.content
                
                # Rebuild history with summary
                self.conversation_history = start + [
                    {"role": "system", "content": f"Previous events: {summary}"}
                ] + end
                
            except Exception as e:
                # If summary fails, just keep recent history
                self.conversation_history = self.conversation_history[-15:]
