"""
Campaign Manager - Manages adventures, modules, and world state
"""

import json
from pathlib import Path


class CampaignManager:
    """Manages campaign modules and progression"""
    
    def __init__(self):
        self.modules_path = Path("modules")
        self.modules_path.mkdir(parents=True, exist_ok=True)
        self.current_module = None
        self.world_state = self.load_world_state()
        
    def load_world_state(self):
        """Load or initialize world state"""
        state_file = self.modules_path / "world_state.json"
        
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Initialize default world state
            world_state = {
                "completed_modules": [],
                "available_modules": [],
                "current_location": "starting_area",
                "world_events": [],
                "npc_relationships": {},
                "faction_reputation": {}
            }
            self.save_world_state(world_state)
            return world_state
            
    def save_world_state(self, state=None):
        """Save world state to file"""
        if state is None:
            state = self.world_state
            
        state_file = self.modules_path / "world_state.json"
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
            
    def get_available_modules(self, character_level):
        """Get list of available adventure modules"""
        # Scan modules directory for available adventures
        available = []
        
        for module_dir in self.modules_path.iterdir():
            if not module_dir.is_dir():
                continue
                
            module_file = module_dir / f"{module_dir.name}_module.json"
            if module_file.exists():
                try:
                    with open(module_file, 'r', encoding='utf-8') as f:
                        module_data = json.load(f)
                        
                    # Check if module is appropriate for character level
                    min_level = module_data.get('min_level', 1)
                    max_level = module_data.get('max_level', 20)
                    
                    if min_level <= character_level <= max_level:
                        available.append({
                            "name": module_data.get('name', module_dir.name),
                            "description": module_data.get('description', ''),
                            "level_range": f"{min_level}-{max_level}",
                            "path": str(module_dir)
                        })
                except Exception:
                    continue
                    
        return available
        
    def start_module(self, module_path):
        """Start a new adventure module"""
        module_dir = Path(module_path)
        module_file = module_dir / f"{module_dir.name}_module.json"
        
        if not module_file.exists():
            raise FileNotFoundError(f"Module file not found: {module_file}")
            
        with open(module_file, 'r', encoding='utf-8') as f:
            module_data = json.load(f)
            
        self.current_module = {
            "name": module_data['name'],
            "path": str(module_dir),
            "data": module_data,
            "progress": {
                "current_area": module_data.get('starting_area', 'entrance'),
                "completed_objectives": [],
                "discovered_locations": []
            }
        }
        
        return self.current_module
        
    def create_basic_module(self, name, description, min_level, max_level):
        """Create a basic adventure module structure"""
        module_name = name.lower().replace(' ', '_')
        module_dir = self.modules_path / module_name
        module_dir.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        (module_dir / "areas").mkdir(exist_ok=True)
        (module_dir / "characters").mkdir(exist_ok=True)
        (module_dir / "monsters").mkdir(exist_ok=True)
        
        # Create module metadata
        module_data = {
            "name": name,
            "description": description,
            "min_level": min_level,
            "max_level": max_level,
            "starting_area": "entrance",
            "areas": ["entrance"],
            "main_quest": {
                "title": f"The {name} Adventure",
                "description": description,
                "objectives": []
            }
        }
        
        module_file = module_dir / f"{module_name}_module.json"
        with open(module_file, 'w', encoding='utf-8') as f:
            json.dump(module_data, f, indent=2)
            
        # Create entrance area
        entrance_data = {
            "id": "entrance",
            "name": "Entrance",
            "description": "The beginning of your adventure.",
            "exits": [],
            "npcs": [],
            "items": [],
            "events": []
        }
        
        area_file = module_dir / "areas" / "entrance.json"
        with open(area_file, 'w', encoding='utf-8') as f:
            json.dump(entrance_data, f, indent=2)
            
        return module_dir
        
    def record_event(self, event_description):
        """Record a significant world event"""
        self.world_state['world_events'].append({
            "description": event_description,
            "timestamp": str(Path.cwd())  # Simplified timestamp
        })
        self.save_world_state()
        
    def update_npc_relationship(self, npc_name, relationship_change):
        """Update relationship with an NPC"""
        if npc_name not in self.world_state['npc_relationships']:
            self.world_state['npc_relationships'][npc_name] = 0
            
        self.world_state['npc_relationships'][npc_name] += relationship_change
        self.save_world_state()
        
    def complete_module(self, module_name):
        """Mark a module as completed"""
        if module_name not in self.world_state['completed_modules']:
            self.world_state['completed_modules'].append(module_name)
            self.save_world_state()
