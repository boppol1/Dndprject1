"""
Character Manager - Handles character creation, progression, and management
"""

import json
from pathlib import Path


class CharacterManager:
    """Manages character data and progression"""
    
    def __init__(self):
        self.saves_path = Path("modules/saves")
        self.saves_path.mkdir(parents=True, exist_ok=True)
        
    def create_character_with_ai(self, name, dm_wrapper):
        """Create a character with AI guidance"""
        print("\nThe AI will guide you through character creation...")
        
        # Ask AI to help with character creation
        prompt = f"""Guide a new player through creating their D&D 5e character named {name}.

Ask them to choose:
1. Race (Human, Elf, Dwarf, Halfling, or other)
2. Class (Fighter, Wizard, Rogue, Cleric, or other)
3. Background (optional)

Keep it simple and welcoming for new players. Explain choices briefly."""

        ai_response = dm_wrapper._send_to_ai(prompt, include_system=True)
        print(f"\n{ai_response}\n")
        
        # Get player choices
        race = input("Your race: ").strip() or "Human"
        char_class = input("Your class: ").strip() or "Fighter"
        background = input("Your background (optional): ").strip() or "Adventurer"
        
        # Create character data structure
        character = {
            "name": name,
            "race": race,
            "class": char_class,
            "background": background,
            "level": 1,
            "xp": 0,
            "max_hp": self._calculate_starting_hp(char_class),
            "current_hp": None,  # Will be set to max_hp
            "attributes": self._generate_attributes(char_class),
            "skills": [],
            "equipment": self._starting_equipment(char_class),
            "inventory": [],
            "gold": self._starting_gold(),
            "spells": [] if self._is_spellcaster(char_class) else None
        }
        
        character["current_hp"] = character["max_hp"]
        
        # Get AI to add personality and backstory
        backstory_prompt = f"""Create a brief backstory (2-3 sentences) for:
Name: {name}
Race: {race}
Class: {char_class}
Background: {background}

Make it interesting but concise."""

        backstory = dm_wrapper._send_to_ai(backstory_prompt)
        character["backstory"] = backstory
        
        print(f"\n{backstory}\n")
        
        return character
        
    def _calculate_starting_hp(self, char_class):
        """Calculate starting HP based on class"""
        hit_dice = {
            "Barbarian": 12,
            "Fighter": 10,
            "Paladin": 10,
            "Ranger": 10,
            "Cleric": 8,
            "Druid": 8,
            "Monk": 8,
            "Rogue": 8,
            "Bard": 8,
            "Warlock": 8,
            "Wizard": 6,
            "Sorcerer": 6
        }
        
        # Get hit die or default to 8
        hd = hit_dice.get(char_class.title(), 8)
        
        # Starting HP = max hit die + CON modifier (assume +1 for now)
        return hd + 1
        
    def _generate_attributes(self, char_class):
        """Generate basic attributes"""
        # Simple standard array
        attributes = {
            "strength": 10,
            "dexterity": 10,
            "constitution": 10,
            "intelligence": 10,
            "wisdom": 10,
            "charisma": 10
        }
        
        # Give small bonuses based on class
        if char_class.lower() in ['fighter', 'barbarian', 'paladin']:
            attributes['strength'] = 15
            attributes['constitution'] = 14
        elif char_class.lower() in ['rogue', 'ranger', 'monk']:
            attributes['dexterity'] = 15
            attributes['constitution'] = 12
        elif char_class.lower() in ['wizard', 'sorcerer']:
            attributes['intelligence'] = 15
            attributes['dexterity'] = 12
        elif char_class.lower() in ['cleric', 'druid']:
            attributes['wisdom'] = 15
            attributes['constitution'] = 12
        elif char_class.lower() in ['bard', 'warlock']:
            attributes['charisma'] = 15
            attributes['dexterity'] = 12
            
        return attributes
        
    def _starting_equipment(self, char_class):
        """Get starting equipment based on class"""
        equipment = {
            "Fighter": ["Longsword", "Shield", "Chain Mail", "Backpack", "Rations (3 days)"],
            "Wizard": ["Quarterstaff", "Component Pouch", "Scholar's Pack", "Spellbook"],
            "Rogue": ["Shortsword", "Dagger", "Leather Armor", "Thieves' Tools", "Burglar's Pack"],
            "Cleric": ["Mace", "Shield", "Chain Mail", "Holy Symbol", "Priest's Pack"],
            "Ranger": ["Longbow", "20 Arrows", "Shortsword", "Leather Armor", "Explorer's Pack"],
            "Barbarian": ["Greataxe", "2 Handaxes", "Javelin (4)", "Explorer's Pack"],
            "Paladin": ["Longsword", "Shield", "Chain Mail", "Holy Symbol", "Priest's Pack"],
            "Druid": ["Quarterstaff", "Leather Armor", "Druidic Focus", "Explorer's Pack"],
            "Monk": ["Quarterstaff", "10 Darts", "Explorer's Pack"],
            "Bard": ["Rapier", "Leather Armor", "Musical Instrument", "Entertainer's Pack"],
            "Warlock": ["Dagger", "Component Pouch", "Scholar's Pack", "Leather Armor"],
            "Sorcerer": ["Dagger", "Component Pouch", "Dungeoneer's Pack", "Light Crossbow"]
        }
        
        return equipment.get(char_class.title(), ["Dagger", "Backpack", "Rations", "Rope"])
        
    def _starting_gold(self):
        """Generate starting gold"""
        import random
        return random.randint(50, 150)
        
    def _is_spellcaster(self, char_class):
        """Check if class is a spellcaster"""
        spellcasters = ['wizard', 'sorcerer', 'cleric', 'druid', 'bard', 'warlock', 'paladin', 'ranger']
        return char_class.lower() in spellcasters
        
    def save_character(self, character):
        """Save character to file"""
        char_name = character['name'].replace(' ', '_')
        save_file = self.saves_path / f"{char_name}.json"
        
        with open(save_file, 'w', encoding='utf-8') as f:
            json.dump(character, f, indent=2)
            
        return save_file
        
    def load_character(self, filename):
        """Load character from file"""
        save_file = self.saves_path / filename
        
        if not save_file.exists():
            raise FileNotFoundError(f"Save file not found: {filename}")
            
        with open(save_file, 'r', encoding='utf-8') as f:
            return json.load(f)
            
    def list_saved_characters(self):
        """List all saved characters"""
        save_files = list(self.saves_path.glob("*.json"))
        characters = []
        
        for save_file in save_files:
            try:
                with open(save_file, 'r', encoding='utf-8') as f:
                    char_data = json.load(f)
                    characters.append({
                        "filename": save_file.name,
                        "name": char_data.get('name', 'Unknown'),
                        "level": char_data.get('level', 1),
                        "class": char_data.get('class', 'Unknown')
                    })
            except Exception:
                continue
                
        return characters
        
    def level_up(self, character):
        """Handle character leveling up"""
        character['level'] += 1
        
        # Increase HP
        hit_die = self._calculate_starting_hp(character['class']) - 1
        import random
        hp_increase = random.randint(1, hit_die) + 1  # Roll + CON modifier
        character['max_hp'] += hp_increase
        character['current_hp'] += hp_increase
        
        return character
